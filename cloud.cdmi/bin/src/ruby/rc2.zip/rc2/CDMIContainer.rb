require 'rubygems'
require 'rest_client'

require './LOG.rb'
require './Misc.rb'
require './JSONUtils.rb'

# CDMI::CONTAINER (RESTFul Operations: CREATE|READ|UPDATE|DELETE)
class CDMIContainer
	def initialize( cdmiEPR )
        @cdmiEPR = cdmiEPR
	end

	# Returns the associated metadata of this container
	def READ( containerName, metadataFields = nil )
		header = {}
        header['Accept']                       = "application/vnd.org.snia.cdmi.container+json"
        header['Content-Type']                 = "application/vnd.org.snia.cdmi.container+json"
        header['X-CDMI-Specification-Version'] = '1.0'
			
		begin
    		url = @cdmiEPR + containerName
    		if ( metadataFields != nil )
    		  url += ("?"+metadataFields)
    		end
    		
			response = RestClient.get url, header
		rescue  # exception ?
			puts $!
			return nil
		else
            responseHeader = response.headers
            responseBody   = JSON.parse( response.body )
            resultStatus   = response.code
            resultHeader   = {}  
            resultBody     = {}  
			
            Misc.getField( resultHeader, responseHeader, 'X-CDMI-Specification-Version')
            Misc.getField( resultHeader, responseHeader, 'Content-Type')
            Misc.getField( resultHeader, responseHeader, 'Location')
            
            Misc.getField( resultBody, responseBody, 'objectURI'        )
            Misc.getField( resultBody, responseBody, 'objectID'         )
            Misc.getField( resultBody, responseBody, 'objectName'       )
            Misc.getField( resultBody, responseBody, 'parentURI'        )
            Misc.getField( resultBody, responseBody, 'domainURI'        )
            Misc.getField( resultBody, responseBody, 'capabilitiesURI'  )
            Misc.getField( resultBody, responseBody, 'completionStatus' )
            Misc.getField( resultBody, responseBody, 'metadata'         ) #more definitions in chapter 16
            Misc.getField( resultBody, responseBody, 'childrenrange'    )
            Misc.getField( resultBody, responseBody, 'children'         )
            Misc.getField( resultBody, responseBody, 'percentComplete'  )
            Misc.getField( resultBody, responseBody, 'exports'          )
            Misc.getField( resultBody, responseBody, 'snapshots'        )
            
      		return [resultStatus,resultHeader,resultBody]
		end
		
		return result
	end
	
	# Updates the metadata of this container and publish it in CDMI server
	def UPDATE( containerName, newMetadata )#toDo PUT <root URI>/<ContainerName>/<TheContainerName>/?metadata
		header={}
		header[ 'Accept'       ] = 'application/cdmi-container'
		header[ 'Content-Type' ] = 'application/cdmi-container'
        header[ 'X-CDMI-Specification-Version'] = '1.0'
		  
		body = {}
		#optional
		Misc.setField( body, 'metadata' , newMetadata )
		Misc.setField( body, 'domainURI', newMetadata )
		Misc.setField( body, 'snapshot' , newMetadata )
		Misc.setField( body, 'exports'  , newMetadata )
		
		begin
    		url = @cdmiEPR + @name
			response = RestClient.put url, header, body
		rescue  # exception ?
			puts $!
			result = nil
		else
            responseHeader = response.headers
            responseBody   = response.body
            resultStatus   = response.code
            resultHeader   = {}  
            resultBody     = {}  
			
            Misc.getMetadataField( resultHeader, responseHeader, 'Location' )
        
      		return [resultStatus,resultHeader,resultBody]
		end
		
		return result
	end
	
	# Removes this container from CDMI server
	def DELETE( containerName )
		header = {}
		header['X-CDMI-Specification-Version'] = '1.0'
		
		begin
	 	    url = @cdmiEPR + @name
			response = RestClient.delete url, header
		rescue  # exception ?
			puts $!
			result = nil
		else
            responseHeader = response.headers
            responseBody   = response.body
            resultStatus   = response.code
            resultHeader   = {}  
            resultBody     = {}  
      		return [resultStatus,resultHeader,resultBody]
		end
		
		return result
	end
	
	# Creates a new container
	def CREATE( containerName, metadata = nil )
		header = {}
		header[ 'Accept'       ] = 'application/vnd.org.snia.cdmi.container+json'
		header[ 'Content-Type' ] = 'application/vnd.org.snia.cdmi.container+json'
        header[ 'X-CDMI-Specification-Version'] = '1.0'
        
		#optional
		body = {}
		Misc.setField( body, 'mimetype'     , metadata )
		Misc.setField( body, 'metadata'     , metadata )
		Misc.setField( body, 'domainURI'    , metadata )
		Misc.setField( body, 'deserialize'  , metadata )
		Misc.setField( body, 'serialize'    , metadata )
		Misc.setField( body, 'copy'         , metadata )
		Misc.setField( body, 'move'         , metadata )
		Misc.setField( body, 'reference'    , metadata )
		
		begin
	 	    url = @cdmiEPR + containerName
			response = RestClient.put url, header, body
		rescue  # exception ?
			puts $!
			result = nil
		else
            responseHeader = response.headers
            responseBody   = response.body
            resultStatus   = response.code
            resultHeader   = {}  
            resultBody     = {}  
            Misc.getField( resultHeader, responseHeader, 'Accept')
            Misc.getField( resultHeader, responseHeader, 'X-CDMI-Specification-Version')
            Misc.getField( resultHeader, responseHeader, 'Location')
            
            Misc.getField( resultBody, responseBody, 'objectURI'        )
            Misc.getField( resultBody, responseBody, 'objectID'         )
            Misc.getField( resultBody, responseBody, 'parentURI'        )
            Misc.getField( resultBody, responseBody, 'domainURI'        )
            Misc.getField( resultBody, responseBody, 'capabilitiesURI'  )
            Misc.getField( resultBody, responseBody, 'completionStatus' )
            Misc.getField( resultBody, responseBody, 'mimetype'         )
            Misc.getField( resultBody, responseBody, 'metadata'         )   # TODO: more Definitions possible see chapter 16 metadata 
            Misc.getField( resultBody, responseBody, 'percentComplete'  )
            
      		return [resultStatus,resultHeader,resultBody]
		end
		
		return result
	end
	
	def dump()
		LOG.echo( "CDMIContainer", "@cdmiEPR ='%s'" % @cdmiEPR )
	end	
	
end  # EOC-CDMIContainer