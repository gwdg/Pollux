require './LOG.rb'
require './CDMIContainer.rb'

class TesterContainer
     def initialize()
     end
     
     def self.readX()
        container = CDMIContainer.new( "http://129.217.252.37:2364/" )
        result = container.READ( "Gerd" )
        LOG.echo( "Tester", result[ 0 ] ) 
        LOG.echo( "Tester", result[ 1 ] ) 
         
        result[ 2 ].each { |item|
           LOG.echo( "Tester", item[ 0 ]+("=%s"%item[1]) ) }
     end
     
     def self.readY()
        container = CDMIContainer.new( "http://129.217.252.37:2364/" )
        result = container.READ( "Gerd", "objectID;objectURI" )
        LOG.echo( "Tester", result[ 0 ] ) 
        LOG.echo( "Tester", result[ 1 ] ) 
         
        result[ 2 ].each { |item|
           LOG.echo( "Tester", item[ 0 ]+("=%s"%item[1]) ) }
     end
     
     def self.create()
        container = CDMIContainer.new( "http://129.217.252.37:2364/" )
        result = container.CREATE( "WubiClub" )
        LOG.echo( "Tester", result[ 0 ] ) 
        LOG.echo( "Tester", result[ 1 ] ) 
         
        result[ 2 ].each { |item|
           LOG.echo( "Tester", item[ 0 ]+("=%s"%item[1]) ) }
     end
end

begin
  TesterContainer.readX()
  TesterContainer.readY()
  TesterContainer.create()
end	
