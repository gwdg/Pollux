require 'logger'
require './ParserUtils.rb'
require './CDMIContainer.rb'

class CDMIServerConnector
	def initialize( cdmiEPR = 'http://localhost:2364/', log = nil )
		@cdmiEPR = cdmiEPR
		@log     = log
		@parser  = ParserUtils.new( log )
		@server  = endpoint[ 0, @parser.findOccurrence( endpoint, "/", 3 ) ];
	end

	# Creates a container 'containerName' using the specified 'metadata'
	def createContainer( containerName, metadata )
		header = {}
		header[ 'X-CDMI-Specification-Version'] = '1.0'
		header[ 'Accept'      ] = 'application/cdmi-container'
		header[ 'Content-Type'] = 'application/cdmi-container'
		
		#body optional
		body = {}
		CDMIContainer.setMetadataField( body, 'metadata'        , metadata )
		CDMIContainer.setMetadataField( body, 'domainURI'       , metadata )
		CDMIContainer.setMetadataField( body, 'exports'         , metadata )
		CDMIContainer.setMetadataField( body, 'deserialize'     , metadata )
		CDMIContainer.setMetadataField( body, 'copy'            , metadata )
		CDMIContainer.setMetadataField( body, 'move'            , metadata )
		CDMIContainer.setMetadataField( body, 'reference'       , metadata )
		CDMIContainer.setMetadataField( body, 'deserializevalue', metadata )
		
		url = @cdmiEPR + '/' + containerName
		begin
			response = RestClient.post url, header, body
		rescue  # exception ?
			puts $!
			result = 'ERROR'
		else
			result = response.body
		end
		
		# TODO: check the returned type and initialize metadataFromCDMI 
		metadataFromCDMI = {}
		CDMIContainer container = CDMIContainer.new( @cdmiEPR, containerName, metadataFromCDMI, @log )
		return container
	end 
	
	def log( msg )
		if ( @log != nil )
			@log.info( "CDMIServerConnector LOG: '%s'" % msg )
		else
			puts  "CDMIServerConnector console: '%s'" % msg 
		end
	end
	
	def how2use()
    	medatata     = {}  # TOBE INITIALIZED
    	newContainer = createContainer( 'gerd', metadata )
    	newMD        = newContainer.fetchMetadata()
    	
    	# DO SOME CHANGES in newMD ...
    	# & UPDATE it IN THE CONTAINER
    	newContainer.updateContainer( newMD )
    	
    	# CREATE AN OBJECT within newContainer
    	# & INITIALIZE its objMetadata
    	objMetadata = {}
    	newContainer.createDataObjectInContainer( 'objectINcdmi', objMetadata )
    	
    	newContainer.delete() # it removes the container from CDMI
	end

end  # EOC-CDMIServerConnector

begin
	connector = CDMIServerConnector.new( 'http://localhost:2364/' )
	connector.how2use()
end 