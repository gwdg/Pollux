require 'logger'
require './CDMIServerUtils.rb'
require './ONEUtils.rb'
require './ParserUtils.rb'

class OCCI2CDMIBroker
     def initialize( endpoint = 'http://localhost:2364/Gerd' )
       @log       = nil #Logger.new( File.open( './OCCI2CDMIBroker.log', 'a') )
       @endpoint  = endpoint
       
	   @parser    = ParserUtils.new( @log )
	   @server    = endpoint[ 0, @parser.findOccurrence( endpoint, "/", 3 ) ];
	   @container = endpoint[ @parser.findOccurrence( endpoint, "/", 3 ) + 1 .. -1 ];
	   
	   @cdmi      = CDMIServerUtils.new( @server, @container, @log )
	   @one       = ONEUtils.new( @log )
     end
	 
	 def useCase()
		isAlive = @cdmi.isAliveCDMIServer()
		log( "isAlive='%s'"%isAlive )
		
		images        = @cdmi.getImages()
		selectedImage = @cdmi.getOne( images )
		imageID       = @cdmi.getImageID( selectedImage )
		
		log( "@images='%s'"%images )
		log( "@selectedImage='%s'" %selectedImage )
		log( "@imageID='%s'"%imageID )
		
		@one.createVM( imageID, @endpoint )
	 end
	 #new
   def create_container(path)
       header = {}
       header['X-CDMI-Specification-Version'] = '1.0'
       header['Accept'] = 'application/cdmi-container'
       header['Content-Type'] = 'application/cdmi-container'
       #body optional
       body = {}
       body['metadata'] = ''
       body['domainURI'] = ''
       body['exports'] = ''
       body['deserialize'] =''
       body['copy']=''
       body['move']=''
       body['reference'] = ''
       body['deserializevalue'] = ''
         container_uri= '/Gerd2'
         url = @endpointendpoint+ container_uri
       response = RestClient.post url, header, body 
       #add exception here
       #puts response
     end 
     
    def get_container(path)
      header = {}
      header['X-CDMI-Specification-Version'] = '1.0'
      header['Accept'] = 'application/cdmi-container'
	    url = @endpoint + container_uri
      response = RestClient.get url, header
      #add exception here
    end
    
    def update_container(path)
      header={}
      header['X-CDMI-Specification-Version'] = '1.0'
      header['Accept'] = 'application/cdmi-container'
      header['Content-Type'] = 'application/cdmi-container'
      #body optional
      body = {}
      body['metadata'] = ''
      body['domainURI'] = ''
      body['snapshot'] = ''
      body['exports'] =''
      url = @endpoint + container_uri
      response = RestClient.put url, header
            #add exception here
    end
    
    def delete_cotainer(path)
      header = {}
      header['X-CDMI-Specification-Version'] = '1.0'
      url = @endpoint + container_uri
      response = RestClient.delete url, header
    end
	 
    def create_dataobject_in_container(path)
      header = {}
      header['X-CDMI-Specification-Version'] = '1.0'
      header['Accept'] = 'application/cdmi_object'
      header['Content-Type'] = 'application/cdmi_object'
      #optional
      body = {}
      body['mimetype'] = ''
      body['metadata'] = ''
      body['domainURI'] = ''
      body['deserialize'] =''
      body['serialize'] = ''
      body['copy']=''
      body['move']=''
      body['reference'] = ''
      body['deserializevalue'] = ''
      body['value']=''
      url = @endpoint + container_uri
      response = RestClient.post url, header, body
      #add exception
    end
    
   def create_dataobject(path)
     header = {}
     header['X-CDMI-Specification-Version'] = '1.0'
     header['Accept'] = 'application/cdmi_object'
     header['Content-Type'] = 'application/cdmi_object'
     #optional 
     #header['X-CDMI-Partial'] = ''
     #optional body
     body = {}
     body['mimetype'] = ''
     body['metadata'] = ''
     body['domainURI'] = ''
     body['deserialize'] =''
     body['serialize'] = ''
     body['copy']=''
     body['move']=''
     body['reference'] = ''
     body['deserializevalue'] = ''
     body['value']=''
     url = @endpoint + container_uri + dataobject_uri
     response = RestClient.put url, header, body
     #add exception
   end
   
   def read_dataobject(path)
     header = {}
     header['X-CDMI-Specification-Version'] = '1.0'
     header['Accept'] = 'application/cdmi_object'
     url = @endpoint + container_uri + dataobject_uri
     response = RestClient.get url, header, body
     #add exception
   end
   
   def update_dataobject(path)
     header = {}
     header['X-CDMI-Specification-Version'] = '1.0'
     header['Accept'] = 'application/cdmi_object'
     header['Content-Type'] = 'application/cdmi_object'
     #optional 
     #header['X-CDMI-Partial'] = ''
     #optional body
     body = {}
     body['mimetype'] = ''
     body['metadata'] = ''
     body['domainURI'] = ''
     body['value'] = ''
     url = @endpoint + container_uri + dataobject_uri
     response = RestClient.put url, header, body
     #add exception
   end
   
  def delete_dataobject(path)
    header = {}
    header['X-CDMI-Specification-Version'] = '1.0'
    url = @endpoint + container_uri + dataobject_uri
    response = RestClient.delete url, header
    #add exception
  end
   
#new ends here
    
	 
	 def dump()
		log( "@endpoint='%s'" %@endpoint  )
		log( "@server='%s'"   %@server    )
		log( "@container='%s'"%@container )
	 end	

		
		
		
	 def log( msg )
        if ( @log != nil )
          @log.info( "OCCI2CDMIBroker LOG: '%s'" % msg )
		else
		  puts  "OCCI2CDMIBroker console: '%s'" % msg 
        end
     end

end  # END-OF-CLASS

begin
    broker = OCCI2CDMIBroker.new()
    broker.useCase()
	broker.dump()
end 