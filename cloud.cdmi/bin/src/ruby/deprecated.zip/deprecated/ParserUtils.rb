require 'logger'

class ParserUtils
     def initialize( logger = Logger.new( File.open( './ParserUtils.log', 'a' ) ) )
       @logger = logger
     end

     def log( msg )
        if ( @logger != nil )
          @logger.info( "ParserUtils LOG: '%s'" % msg )
		else
		  #puts msg
        end
     end

	def findOccurrence( var, substring, n )
		log( 'looking in \'' + var + '\' for \'' + substring + '\'' )
		position = -1

		if n == 1
			position = var.index( substring )
			if ( position == nil )
				position = -1
			end
			return position
		else
			i = 0
			while i < n do
				position = var.index(substring, position+1)
				if position != nil
					i += 1
				else
					break
				end
			end
			if ( position == nil )
				position = -1
			end
			return position
		end
		return position
	end
  
	def getValue( var, key )
      result = nil
      tobeSearch = '"' + key + '":'
      idx = findOccurrence( var, tobeSearch, 1 )
      if idx != -1  # key found
        subSTR = "%s"%var[ idx .. -1 ]
	    log( 'phase 1: \'' + subSTR + '\'' )
		result = secondPhase( subSTR, key )
	    log( 'phase 2: \'' + result + '\'' )
      end
      return result
    end
	
	def getArray( var, key )
      result = nil
      tobeSearch = '"' + key + '":'
      idx = findOccurrence( var, tobeSearch, 1 )
      if idx != -1  # key found
        subSTR = "%s"%var[ idx .. -1 ]
	    log( 'phase 1: \'' + subSTR + '\'' )
		result = secondPhase4Array( subSTR, key )
	    log( 'phase 2: \'' + result + '\'' )
      end
      return result
    end
	
	def buildArray( var, extension )
		# expected var:  "file1.img", "dir.txt", "image.jpg", "image2.img"
		items  = var.split( "," )
		result = []
		items.each do
			|it|
			filename = it.rstrip.lstrip.delete( '"' )
			if ( filename.end_with?( extension ) )
				result.push( filename )
			end
		end
		
		return result
	end
	
	def secondPhase( chain, key )
	    limiter = '"'
		varA = findOccurrence( chain, limiter, 3 )
		varB = findOccurrence( chain, limiter, 4 )
		result = chain[ varA+1 .. varB-1 ]
		return result
	end
	
	def secondPhase4Array( chain, key )
	    limiterA = '['
	    limiterB = ']'
		varA = findOccurrence( chain, limiterA, 1 )
		varB = findOccurrence( chain, limiterB, 1 )
		result = chain[ varA+1 .. varB-1 ]
		return result
	end
	
	def example()
		log( "--" * 30 )
		response = '{"completionStatus": "Complete", "objectID": "AABRbgANCVIvR2VyZA==", "parentURI": "/", "objectURI": "/Gerd", "childrenrange": "0-3", "children": ["ttylinux.img", "bild.png", "myfile.text"], "metadata": {"cdmi_ctime": "2011-07-29T14:40:20.837353", "cdmi_mtime": "2011-07-29T14:40:20.837353", "cdmi_size": 4096, "cdmi_atime": "2011-08-11T15:53:33.534704"}}'
		key = "objectID"
		log( "key='%s', value='%s'" % [ key , getValue( response, key ) + "'" ] )
	end
	
	def example4array()
		log( "--" * 30 )
		response = '{"completionStatus": "Complete", "objectID": "AABRbgANCVIvR2VyZA==", "parentURI": "/", "objectURI": "/Gerd", "childrenrange": "0-3", "children": ["ttylinux.img", "bild.png", "myfile.text"], "metadata": {"cdmi_ctime": "2011-07-29T14:40:20.837353", "cdmi_mtime": "2011-07-29T14:40:20.837353", "cdmi_size": 4096, "cdmi_atime": "2011-08-11T15:53:33.534704"}}'
		key = "children"
		log( "key='%s', value='%s'" % [ key , getArray( response, key ) + "'" ] )
	end
end

begin
	# utils = ParserUtils.new()
	# utils.example()
	# utils.example()
	
	#utils = ParserUtils.new( nil )
	#result = utils.buildArray( '"file1.img", "photo.jpg",  "file2.img", "config.xml"', "img" )
	#puts "items:%s"%result.length
	#result.each { |i| print i, ":"}
end	
