require 'rubygems'
require 'restclient'
require 'logger'
require 'json'
require './ParserUtils.rb'

class CDMIServerUtils

    def initialize( server, container, logger = Logger.new( File.open( './CDMIServerUtils.log', 'a' ) ) )
       @server    = server
	   @container = container
	   @logger    = logger
	   @parser    = ParserUtils.new( logger )
	   
	   RestClient.log = Logger.new( STDOUT )
    end
	 
	def getImages()
		# get images from cdmi server
       log( "getImages (-start-)" )
       header = {}
       header['X-CDMI-Specification-Version'] = '1.0'
       header['Content-Type'] = '*/*'
       url = @server + ( '/%s/'%@container )
	   log( "getImages (-url:%s-)"%url ) 
	   response = ''
       begin
         response = RestClient.get url, header
       rescue  # exception ?
		 puts $!
         result = 'ERROR'
       else
         result = response.body
       end
       log( "getImages (response:%s)"%[result] )
	   children = @parser.getArray( result, "children" )
       log( "getImages (children:%s)"%[children] )
       log( "getImages (-end-)"  )
	   
	   return @parser.buildArray( children, "img" )
	end

	def getOne( images )
		#it selects an image randomly and returns it back.
		idx = rand(2**256)
		return images[ idx % images.length ]
	end

	def getImageID( image )
       log( "getImageID (-start-)" )
       header = {}
       header['X-CDMI-Specification-Version'] = '1.0'
       header['Content-Type'] = '*/*'
       url = @server + ('/%s/%s?objectID'%[@container,image])
	   log( "getImageID (-url:%s-)"%url ) 
	   response = ''
       begin
         response = RestClient.get url, header
       rescue  # exception ?
         response = ''
		 puts $!
       else
         response = response.body
       end
	   
	   if ( response != '' )
		  response = @parser.getValue( response, "objectID" )
	   end
	   
       log( "getImageID (response:%s)"%[response] )
       log( "getImageID (-end-)"  )
	   
       return response
	end

	def log( msg )
        if ( @logger != nil )
          @logger.info( "CDMIServerUtils LOG: '%s'" % msg )
		else
		  puts  "CDMIServerUtils console: '%s'" % msg 
        end
     end

     def isAliveCDMIServer
       log( "isAliveCDMIServer (-start-)" )
       header = {}
       header['X-CDMI-Specification-Version'] = '1.0'
       header['Content-Type'] = '*/*'
       url = @server + '/cdmi_capabilities/'
	   log( "isAliveCDMIServer (-url:%s-)"%url ) 
	   response = ''
       begin
         response = RestClient.get url, header
       rescue  # exception ?
         alive = false
		 puts $!
       else
         alive = true
       end
       log( "isAliveCDMIServer (response:%s)"%[alive] )
       log( "isAliveCDMIServer (-end-)"  )
       return alive
     end

     def self.exampleGetObjectID()
		server = CDMIServerUtils.new( "http://localhost:2364", "Gerd", nil )
        id = server.getImageID( 'wubi.img' )
	    server.log(id)
     end
	 
	 def self.exampleGetImages()
		server = CDMIServerUtils.new( "http://localhost:2364", "Gerd", nil )
		images = server.getImages()
		images.each { |i| puts i }
	 end
	 
	 def self.exampleGetOne()
		server = CDMIServerUtils.new( "http://localhost:2364", "Gerd", nil )
		images = ["f1.img", "abc456.img", "av.img", "trier.img"]
		selected = server.getOne(images)
		server.log(selected)
	 end
end  # END-OF-CLASS

begin
    #CDMIServerUtils.exampleGetImages()
end 