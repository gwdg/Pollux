require 'logger'
require './ParserUtils.rb'

class CDMIContainer
	def initialize( cdmiEPR, name, metadata = nil, log = nil )
        @cdmiEPR  = cdmiEPR
        @name     = '/'+name;
        @metadata = metadata;
        @log      = log
        @parser   = ParserUtils.new( log )
	end

	# Returns the associated/cached metadata of this container
	def getMetadata()
		return @metadata
	end

	# Returns the associated metadata of this container
	def fetchMetadata()
		header = {}
		header['X-CDMI-Specification-Version'] = '1.0'
		header['Accept'] = 'application/cdmi-container'
		
		begin
    		url = @cdmiEPR + @name
			response = RestClient.get url, header
		rescue  # exception ?
			puts $!
			result = 'ERROR'
		else
			result = response.body
		end
		
		# TODO: parse result and return a hashtable with metadata fields
		return result
	end
	
	# Updates the metadata of this container and publish it in CDMI server
	def updateContainer( newMetadata )
	    @metadata = newMetadata
	    
		header={}
		header[ 'X-CDMI-Specification-Version'] = '1.0'
		header[ 'Accept'       ] = 'application/cdmi-container'
		header[ 'Content-Type' ] = 'application/cdmi-container'
		
		body = {}
		CDMIContainer.setMetadataField( body, 'metadata' , newMetadata )
		CDMIContainer.setMetadataField( body, 'domainURI', newMetadata )
		CDMIContainer.setMetadataField( body, 'snapshot' , newMetadata )
		CDMIContainer.setMetadataField( body, 'exports'  , newMetadata )
		
		begin
    		url = @cdmiEPR + @name
			response = RestClient.put url, header, body
		rescue  # exception ?
			puts $!
			result = 'ERROR'
		else
			result = response.body
		end
		
		# TODO:  check the returned result:  BOOL ?
		return result
	end
	
	# Removes this container from CDMI server
	def deleteContainer()
		header = {}
		header['X-CDMI-Specification-Version'] = '1.0'
		
		begin
	 	    url = @cdmiEPR + @name
			response = RestClient.delete url, header
		rescue  # exception ?
			puts $!
			result = 'ERROR'
		else
			result = response.body
		end
	end
	
	# Creates an Object within this container
	def createDataObjectInContainer( objectName, metadata )
		header = {}
		header[ 'X-CDMI-Specification-Version'] = '1.0'
		header[ 'Accept'       ] = 'application/cdmi_object'
		header[ 'Content-Type' ] = 'application/cdmi_object'
		#optional
		body = {}
		CDMIContainer.setMetadataField( body, 'mimetype'        , metadata )
		CDMIContainer.setMetadataField( body, 'metadata'        , metadata )
		CDMIContainer.setMetadataField( body, 'domainURI'       , metadata )
		CDMIContainer.setMetadataField( body, 'deserialize'     , metadata )
		CDMIContainer.setMetadataField( body, 'serialize'       , metadata )
		CDMIContainer.setMetadataField( body, 'copy'            , metadata )
		CDMIContainer.setMetadataField( body, 'move'            , metadata )
		CDMIContainer.setMetadataField( body, 'reference'       , metadata )
		CDMIContainer.setMetadataField( body, 'deserializevalue', metadata )
		body[ 'value' ] = objectName
		
		begin
	 	    url = @cdmiEPR + @name
			response = RestClient.post url, header, body
		rescue  # exception ?
			puts $!
			result = 'ERROR'
		else
			result = response.body
		end
		
		# TODO:  check the returned type
		return result
	
	end
	
	# Creates an Object within this container
	def createDataObject( objectContent, metadata )
		header = {}
		header[ 'X-CDMI-Specification-Version'] = '1.0'
		header[ 'Accept'       ] = 'application/cdmi_object'
		header[ 'Content-Type' ] = 'application/cdmi_object'
		#optional 
		#header[ 'X-CDMI-Partial' ] = ''
		
		#optional body
		CDMIContainer.setMetadataField( body, 'mimetype'        , metadata )
		CDMIContainer.setMetadataField( body, 'metadata'        , metadata )
		CDMIContainer.setMetadataField( body, 'domainURI'       , metadata )
		CDMIContainer.setMetadataField( body, 'deserialize'     , metadata )
		CDMIContainer.setMetadataField( body, 'serialize'       , metadata )
		CDMIContainer.setMetadataField( body, 'copy'            , metadata )
		CDMIContainer.setMetadataField( body, 'move'            , metadata )
		CDMIContainer.setMetadataField( body, 'reference'       , metadata )
		CDMIContainer.setMetadataField( body, 'deserializevalue', metadata )
		body[ 'value' ] = objectContent
		
		begin
	 	    url = @cdmiEPR + @name
			response = RestClient.post url, header, body
		rescue  # exception ?
			puts $!
			result = 'ERROR'
		else
			result = response.body
		end
		
		# TODO:  check the returned type
		return result
	end
	
	# Returns an Object (as binary stream or a new file) from the 'containerName' 
	def readDataObject( objectName )
		header = {}
		header[ 'X-CDMI-Specification-Version'] = '1.0'
		header[ 'Accept' ] = 'application/cdmi_object'
		
		begin
	 	    url = @cdmiEPR + @name + '/' + objectName
			response = RestClient.get url, header, body
		rescue  # exception ?
			puts $!
			result = 'ERROR'
		else
			result = response.body
		end
		
		# TODO:  check the returned type
		return result
	end
	
	# Updates the content of an Object
	def updateDataObject( objectName, newMetadata )
		header = {}
		header[ 'X-CDMI-Specification-Version'] = '1.0'
		header[ 'Accept'       ] = 'application/cdmi_object'
		header[ 'Content-Type' ] = 'application/cdmi_object'
		#optional 
		#header['X-CDMI-Partial'] = ''
		#optional body
		body = {}
		CDMIContainer.setMetadataField( body, 'mimetype' , newMetadata )
		CDMIContainer.setMetadataField( body, 'metadata' , newMetadata )
		CDMIContainer.setMetadataField( body, 'domainURI', newMetadata )
		body[ 'value' ] = objectName
		
		begin
	 	    url = @cdmiEPR + @name + '/' + objectName
			response = RestClient.put url, header, body
		rescue  # exception ?
			puts $!
			result = 'ERROR'
		else
			result = response.body
		end
		
		# TODO:  check the returned type
		return result
	end
	
	# Removes an Object from the 'containerName' 
	def deleteDataObject( objectName )
		header = {}
		header['X-CDMI-Specification-Version'] = '1.0'

		begin
	 	    url = @cdmiEPR + @name + '/' + objectName
			response = RestClient.delete url, header
		rescue  # exception ?
			puts $!
			result = 'ERROR'
		else
			result = response.body
		end
	end
	
	def dump()
		log( "@cdmiEPR ='%s'" % @cdmiEPR  )
		log( "@name    ='%s'" % @name     )
		log( "@metadata='%s'" % @metadata )
	end	
	
	def log( msg )
		if ( @log != nil )
			@log.info( "CDMIContainer LOG: '%s'" % msg )
		else
			puts  "CDMIContainer console: '%s'" % msg 
		end
	end
	
	def self.setMetadataField( body, field, metadata )
		value = metadata[ field ]
		if ( value != nil )
			body[ field ] = value
		end
	end

end  # EOC-CDMIContainer