require 'json'
require './LOG.rb'

class JSONUtils
     def initialize()
     end
end

begin
	# utils = ParserUtils.new()
	# utils.example()
	# utils.example()
end	
