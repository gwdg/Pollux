require './LOG.rb'
require './CDMIContainer.rb'
require './CDMIDataObject.rb'

class TesterDataObject
     def initialize()
     end
     
     def self.create( server, container )
        dataobject = CDMIDataObject.new( server, container )
		metadata = {}
		metadata[ 'mimetype' ] = "text/plain"
		metadata[ 'metadata' ] = {}
        result = dataobject.CREATE( "wubix.txt", metadata, "/home/gsikora/example.dat" )
        LOG.echo( "Tester::create-(0)", result[ 0 ] ) 
        result[ 1 ].each { |item|
          LOG.echo( "Tester::create-(1)", item[ 0 ]+("=%s"%item[1]) ) }
                
        result[ 2 ].each { |item|
          LOG.echo( "Tester::create-(2)", item ) }
     end
     
    def self.createnonCDMI( server, container )
      dataobject = CDMIDataObject.new( server, container )
        result = dataobject.nonCDMICreate( "ttylinux.img", "/home/gsikora/ttylinux.img" )
        LOG.echo( "Tester::noncreate-(0)", result[ 0 ] )
        result[ 1 ].each { |item|
           LOG.echo( "Tester::noncreate-(1)", item[ 0 ]+("=%s"%item[1]) ) }
           
        result[ 2 ].each { |item|
          LOG.echo( "Tester::noncreate-(2)", item ) }
    end
    
     def self.readX( server, container )
        dataobject = CDMIDataObject.new( server, container )
		metadata = {}
		metadata[ 'mimetype' ] = "text/plain"
		metadata[ 'metadata' ] = {}
        result = dataobject.READ( "wubix.txt" )
        LOG.echo( "Tester::readX-(0)", result[ 0 ] ) 
        result[ 1 ].each { |item|
          LOG.echo( "Tester::readX-(1)", item[ 0 ]+("=%s"%item[1]) ) }
                
        result[ 2 ].each { |item|
          LOG.echo( "Tester::readX-(2)", item ) }
     end
     
     def self.readY( server, container )
        dataobject = CDMIDataObject.new( server, container )
        result = dataobject.READ( "wubix.txt", "mimetype;objectID;objectURI" )
        LOG.echo( "Tester::readY-(0)", result[ 0 ] ) 
        result[ 1 ].each { |item|
          LOG.echo( "Tester::readY-(1)", item[ 0 ]+("=%s"%item[1]) ) }
                
        result[ 2 ].each { |item|
          LOG.echo( "Tester::readY-(2)", item ) }
     end
     
     def self.update( server, container )
        dataobject = CDMIDataObject.new( server, container )
        result = dataobject.READ( "wubix.txt", "mimetype;objectID;objectURI" )
        LOG.echo( "Tester::update-(0)", result[ 0 ] ) 
        result[ 1 ].each { |item|
          LOG.echo( "Tester::update-(1)", item[ 0 ]+("=%s"%item[1]) ) }
                
        result[ 2 ].each { |item|
          LOG.echo( "Tester::update-(2)", item ) }
     end
     
     def self.read( server, container )
        dataobject = CDMIDataObject.new( server, container )
        result = dataobject.READ( "wubix.txt" )
        LOG.echo( "Tester::read-(0)", result[ 0 ] ) 
        result[ 1 ].each { |item|
          LOG.echo( "Tester::read-(1)", item[ 0 ]+("=%s"%item[1]) ) }
                
        result[ 2 ].each { |item|
          LOG.echo( "Tester::read-(2)", item ) }
     end
     
     def self.delete( server, container )
        dataobject = CDMIDataObject.new( server, container )
        result = dataobject.DELETE( "wubix.txt" )
        LOG.echo( "Tester::delete", result ) 
     end
	 
end

begin
	server    = "http://129.217.252.37:2364/"
	container = "WubiClubTMP"
	
	cdmiC = CDMIContainer.new( server )
	cdmiC.CREATE( container )

	TesterDataObject.create( server, container )
	TesterDataObject.readX( server, container )
	TesterDataObject.readY( server, container )
	#TesterDataObject.update( server, container )
	#TesterDataObject.read( server, container )
	#TesterDataObject.delete( server, container )
  #TesterDataObject.createnonCDMI( server, container )
	
	#cdmiC.DELETE( "WubiClubTMP" )
end	
