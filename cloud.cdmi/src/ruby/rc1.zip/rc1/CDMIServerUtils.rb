require 'rubygems'
require 'restclient'
require 'json'
require './LOG.rb'
require './ParserUtils.rb'

class CDMIServerUtils

    def initialize( server, container )
       @server    = server
	   @container = container
	   @parser    = ParserUtils.new()
	   
	   RestClient.log = Logger.new( STDOUT )
    end
	 
	def getImages()
		# get images from cdmi server
       LOG.log( "CDMIServerUtils", "getImages (-start-)" )
       header = {}
       header['X-CDMI-Specification-Version'] = '1.0'
       header['Content-Type'] = '*/*'
       url = @server + ( '/%s/'%@container )
	   LOG.log( "CDMIServerUtils", "getImages (-url:%s-)"%url ) 
	   response = ''
       begin
         response = RestClient.get url, header
       rescue  # exception ?
		 puts $!
         result = 'ERROR'
       else
         result = response.body
       end
       LOG.log( "CDMIServerUtils", "getImages (response:%s)"%[result] )
	   children = @parser.getArray( result, "children" )
       LOG.log( "CDMIServerUtils", "getImages (children:%s)"%[children] )
       LOG.log( "CDMIServerUtils", "getImages (-end-)"  )
	   
	   return @parser.buildArray( children, "img" )
	end

	def getOne( images )
		#it selects an image randomly and returns it back.
		idx = rand(2**256)
		return images[ idx % images.length ]
	end

	def getImageID( image )
       LOG.log( "CDMIServerUtils", "getImageID (-start-)" )
       header = {}
       header['X-CDMI-Specification-Version'] = '1.0'
       header['Content-Type'] = '*/*'
       url = @server + ('/%s/%s?objectID'%[@container,image])
	   LOG.log( "CDMIServerUtils", "getImageID (-url:%s-)"%url ) 
	   response = ''
       begin
         response = RestClient.get url, header
       rescue  # exception ?
         response = ''
		 puts $!
       else
         response = response.body
       end
	   
	   if ( response != '' )
		  response = @parser.getValue( response, "objectID" )
	   end
	   
       LOG.log( "CDMIServerUtils", "getImageID (response:%s)"%[response] )
       LOG.log( "CDMIServerUtils", "getImageID (-end-)"  )
	   
       return response
	end

     def isAliveCDMIServer
       LOG.log( "CDMIServerUtils", "isAliveCDMIServer (-start-)" )
       header = {}
       header['X-CDMI-Specification-Version'] = '1.0'
       header['Content-Type'] = '*/*'
       url = @server + '/cdmi_capabilities/'
	   LOG.log( "CDMIServerUtils", "isAliveCDMIServer (-url:%s-)"%url ) 
	   response = ''
       begin
         response = RestClient.get url, header
       rescue  # exception ?
         alive = false
		 puts $!
       else
         alive = true
       end
       LOG.log( "CDMIServerUtils", "isAliveCDMIServer (response:%s)"%[alive] )
       LOG.log( "CDMIServerUtils", "isAliveCDMIServer (-end-)"  )
       return alive
     end

     def self.exampleGetObjectID()
		server = CDMIServerUtils.new( "http://localhost:2364", "Gerd" )
        id = server.getImageID( 'wubi.img' )
	    LOG.log( "CDMIServerUtils", id )
     end
	 
	 def self.exampleGetImages()
		server = CDMIServerUtils.new( "http://localhost:2364", "Gerd" )
		images = server.getImages()
		images.each { |i| puts i }
	 end
	 
	 def self.exampleGetOne()
		server = CDMIServerUtils.new( "http://localhost:2364", "Gerd" )
		images = ["f1.img", "abc456.img", "av.img", "trier.img"]
		selected = server.getOne(images)
		LOG.log( "CDMIServerUtils", selected )
	 end
end  # END-OF-CLASS

begin
    #CDMIServerUtils.exampleGetImages()
end 