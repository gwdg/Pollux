
class Misc

	def self.setMetadataField( target, field, metadata )
		value = metadata[ field ]
		if ( value != nil )
			target[ field ] = value
		end
	end

	def self.getMetadataField( source, field )
	     # TODO:  USE JSON for extracting field from source (JSON string) 
		value = source[ field ]
	    return value
	end
end
