require './LOG.rb'
require './Misc.rb'
require './ParserUtils.rb'

class CDMIContainer
	def initialize( cdmiEPR, name, metadata = nil )
        @cdmiEPR  = cdmiEPR
        @name     = '/'+name;
        @metadata = metadata;
        @parser   = ParserUtils.new()
	end

	# Returns the associated/cached metadata of this container
	def fetchMetadata()
		return @metadata
	end

	# Returns the associated metadata of this container
	def getMetadata() #to Do GET <root URI>/<ContainerName>/<TheContainerName>/?<fieldname>;<fieldname>;...
		header = {}
        header['Accept'] = 'application/cdmi-container'
		header['X-CDMI-Specification-Version'] = '1.0'
			
		begin
    		url = @cdmiEPR + @name
			response = RestClient.get url, header
		rescue  # exception ?
			puts $!
			result = 'ERROR'
		else
			result = response.body #header +status
		end
		
        Misc.getMetadataField( header, 'X-CDMI-Specification-Version')
        Misc.getMetadataField( header, 'Content-Type')
        Misc.getMetadataField( header, 'Location')
        
        Misc.getMetadataField( body, 'objectURI')
        Misc.getMetadataField( body, 'objectID')
        Misc.getMetadataField( body, 'objectName')
        Misc.getMetadataField( body, 'parentURI')
        Misc.getMetadataField( body, 'domainURI')
        Misc.getMetadataField( body, 'capabilitiesURI')
        Misc.getMetadataField( body, 'completionStatus')
        Misc.getMetadataField( body, 'metadata') #more definitions in chapter 16
        Misc.getMetadataField( body, 'childrenrange')
        Misc.getMetadataField( body, 'children')
        #optional retuns only if present
        #Misc.getMetadataField( body, 'percentComplete')
        #Misc.getMetadataField( body, 'exports')
        #Misc.getMetadataField( body, 'snapshots')
    
		return result
	end
	
	# Updates the metadata of this container and publish it in CDMI server
	def updateContainer( newMetadata )#toDo PUT <root URI>/<ContainerName>/<TheContainerName>/?metadata
	    @metadata = newMetadata
	    
		header={}
		header[ 'Accept'       ] = 'application/cdmi-container'
		header[ 'Content-Type' ] = 'application/cdmi-container'
        header[ 'X-CDMI-Specification-Version'] = '1.0'
		  
		body = {}
		#optional
		Misc.setMetadataField( body, 'metadata' , newMetadata )
		Misc.setMetadataField( body, 'domainURI', newMetadata )
		Misc.setMetadataField( body, 'snapshot' , newMetadata )
		Misc.setMetadataField( body, 'exports'  , newMetadata )
		
		begin
    		url = @cdmiEPR + @name
			response = RestClient.put url, header, body
		rescue  # exception ?
			puts $!
			result = 'ERROR'
		else
			result = response.header # +status 
		end
		
        Misc.getMetadataField( header, 'Location')
    
		return result
	end
	
	# Removes this container from CDMI server
	def deleteContainer()
		header = {}
		header['X-CDMI-Specification-Version'] = '1.0'
		
		begin
	 	    url = @cdmiEPR + @name
			response = RestClient.delete url, header
		rescue  # exception ?
			puts $!
			result = 'ERROR'
		else
			result = response.status #204 No Content (container object was deleted)
		end
	end
	
	# Creates an Object within this container
	def createDataObjectInContainer( objectName, metadata ) #toDo POST <root URI>/cdmi_objectid/
		header = {}
		header[ 'Accept'       ] = 'application/cdmi_object'
		header[ 'Content-Type' ] = 'application/cdmi_object'
        header[ 'X-CDMI-Specification-Version'] = '1.0'
		#optional
		body = {}
		Misc.setMetadataField( body, 'mimetype'        , metadata )
		Misc.setMetadataField( body, 'metadata'        , metadata )
		Misc.setMetadataField( body, 'domainURI'       , metadata )
		Misc.setMetadataField( body, 'deserialize'     , metadata )
		Misc.setMetadataField( body, 'serialize'       , metadata )
		Misc.setMetadataField( body, 'copy'            , metadata )
		Misc.setMetadataField( body, 'move'            , metadata )
		Misc.setMetadataField( body, 'reference'       , metadata )
		Misc.setMetadataField( body, 'deserializevalue', metadata )
		body[ 'value' ] = objectName
		
		begin
	 	    url = @cdmiEPR + @name
			response = RestClient.post url, header, body
		rescue  # exception ?
			puts $!
			result = 'ERROR'
		else
			result = response.body#+header and status
		end
		
        Misc.getMetadataField( header, 'Accept')
        Misc.getMetadataField( header, 'X-CDMI-Specification-Version')
        Misc.getMetadataField( header, 'Location')
        
        Misc.getMetadataField( body, 'objectURI')
        Misc.getMetadataField( body, 'objectID')
        Misc.getMetadataField( body, 'parentURI')
        Misc.getMetadataField( body, 'domainURI')
        Misc.getMetadataField( body, 'capabilitiesURI')
        Misc.getMetadataField( body, 'completionStatus')
        Misc.getMetadataField( body, 'mimetype')
        Misc.getMetadataField( body, 'metadata') ##to Do: more Definitions possible see chapter 16 metadata 
        #optional
        #Misc.getMetadataField( body, 'percentComplete')
		return result
	
	end
	
	# Creates an Object with name
	def createDataObject( objectContent, metadata )
		header = {}
		header[ 'Accept'       ] = 'application/cdmi_object'
		header[ 'Content-Type' ] = 'application/cdmi_object'
        header[ 'X-CDMI-Specification-Version'] = '1.0'
		#optional 
		#header[ 'X-CDMI-Partial' ] = ''
		
		#optional body
		Misc.setMetadataField( body, 'mimetype'        , metadata )
		Misc.setMetadataField( body, 'metadata'        , metadata )
		Misc.setMetadataField( body, 'domainURI'       , metadata )
		Misc.setMetadataField( body, 'deserialize'     , metadata )
		Misc.setMetadataField( body, 'serialize'       , metadata )
		Misc.setMetadataField( body, 'copy'            , metadata )
		Misc.setMetadataField( body, 'move'            , metadata )
		Misc.setMetadataField( body, 'reference'       , metadata )
		Misc.setMetadataField( body, 'deserializevalue', metadata )
		body[ 'value' ] = objectContent
		
		begin
	 	    url = @cdmiEPR + @name
			response = RestClient.put url, header, body
		rescue  # exception ?
			puts $!
			result = 'ERROR'
		else
			result = response.body #+header and status
		end
		
        Misc.getMetadataField( header, 'Content-Type')
        Misc.getMetadataField( header, 'X-CDMI-Specification-Version')
        
        Misc.getMetadataField( body, 'objectURI')
        Misc.getMetadataField( body, 'objectID')
        Misc.getMetadataField( body, 'objectName')
        Misc.getMetadataField( body, 'parentURI')
        Misc.getMetadataField( body, 'domainURI')
        Misc.getMetadataField( body, 'capabilitiesURI')
        Misc.getMetadataField( body, 'completionStatus')
        Misc.getMetadataField( body, 'mimetype')
        Misc.getMetadataField( body, 'metadata')#more definitions in chapter 16 metadata
        #optional
        #Misc.getMetadataField( body, 'percentComplete')
    
		return result
	end
	
	# Returns an Object (as binary stream or a new file) from the 'containerName' 
	def readDataObject( objectName ) #toDo GET <root URI>/<ContainerName>/<DataObjectName>?<fieldname>;<fieldname>;...
		header = {}
		header[ 'Accept' ] = 'application/cdmi_object'
        header[ 'X-CDMI-Specification-Version'] = '1.0'
		
		begin
	 	    url = @cdmiEPR + @name + '/' + objectName
			response = RestClient.get url, header, body
		rescue  # exception ?
			puts $!
			result = 'ERROR'
		else
			result = response.body#header+status
		end
		
        Misc.getMetadataField( header, 'X-CDMI-Specification-Version')
        Misc.getMetadataField( header, 'Content-Type')
        Misc.getMetadataField( header, 'Location')
        
        Misc.getMetadataField( body, 'objectURI')
        Misc.getMetadataField( body, 'objectID')
        Misc.getMetadataField( body, 'objectName')
        Misc.getMetadataField( body, 'parentURI')
        Misc.getMetadataField( body, 'domainURI')
        Misc.getMetadataField( body, 'capabilitiesURI')
        Misc.getMetadataField( body, 'completionStatus')
        Misc.getMetadataField( body, 'mimetype')
        Misc.getMetadataField( body, 'metadata')#more definitions in chapter 16 metadata
        Misc.getMetadataField( body, 'valuerange')
        Misc.getMetadataField( body, 'value')
        #optional
        #Misc.getMetadataField( body, 'percentComplete')
        #
		return result
	end
	
	# Updates the content of an Object
	def updateDataObject( objectName, newMetadata ) #to Do PUT <root URI>/<ContainerName>/<DataObjectName>?<fieldname> 
		header = {}
		header[ 'Accept'       ] = 'application/cdmi_object'
		header[ 'Content-Type' ] = 'application/cdmi_object'
        header[ 'X-CDMI-Specification-Version'] = '1.0'
		#optional 
		#header['X-CDMI-Partial'] = ''
		#optional body
		body = {}
		Misc.setMetadataField( body, 'mimetype' , newMetadata )
		Misc.setMetadataField( body, 'metadata' , newMetadata )
		Misc.setMetadataField( body, 'domainURI', newMetadata )
		body[ 'value' ] = objectName
		
		begin
	 	    url = @cdmiEPR + @name + '/' + objectName
			response = RestClient.put url, header, body
		rescue  # exception ?
			puts $!
			result = 'ERROR'
		else
			result = response.header #+status
		end
	
        Misc.getMetadataField( header, 'Location')
   
		return result
	end
	
	# Removes an Object from the 'containerName' 
	def deleteDataObject( objectName )
		header = {}
		header['X-CDMI-Specification-Version'] = '1.0'

		begin
	 	    url = @cdmiEPR + @name + '/' + objectName
			response = RestClient.delete url, header
		rescue  # exception ?
			puts $!
			result = 'ERROR'
		else
			result = response.status
		end
	end
	
	def dump()
		LOG.echo( "CDMIContainer", "@cdmiEPR ='%s'" % @cdmiEPR  )
		LOG.echo( "CDMIContainer", "@name    ='%s'" % @name     )
		LOG.echo( "CDMIContainer", "@metadata='%s'" % @metadata )
	end	
	
end  # EOC-CDMIContainer