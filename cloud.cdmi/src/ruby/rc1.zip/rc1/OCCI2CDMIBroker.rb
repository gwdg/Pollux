require './CDMIServerUtils.rb'
require './LOG.rb'
require './ONEUtils.rb'
require './ParserUtils.rb'

class OCCI2CDMIBroker
     def initialize( endpoint = 'http://129.217.252.37:2364/Gerd' )
       @endpoint  = endpoint
       
	   @parser    = ParserUtils.new()
	   @server    = endpoint[ 0, @parser.findOccurrence( endpoint, "/", 3 ) ];
	   @container = endpoint[ @parser.findOccurrence( endpoint, "/", 3 ) + 1 .. -1 ];
	   
	   @cdmi      = CDMIServerUtils.new( @server, @container )
	   @one       = ONEUtils.new()
     end
	 
	 def useCase()
		isAlive = @cdmi.isAliveCDMIServer()
		LOG.log( "OCCI2CDMIBroker", "isAlive='%s'"%isAlive )
		
		images        = @cdmi.getImages()
		selectedImage = @cdmi.getOne( images )
		imageID       = @cdmi.getImageID( selectedImage )
		
		LOG.log( "OCCI2CDMIBroker", "@images='%s'"%images )
		LOG.log( "OCCI2CDMIBroker", "@selectedImage='%s'" %selectedImage )
		LOG.log( "OCCI2CDMIBroker", "@imageID='%s'"%imageID )
		
		@one.createVM( imageID, @endpoint )
	 end
	 #new
   def create_container(path)
       header = {}
       header['X-CDMI-Specification-Version'] = '1.0'
       header['Accept'] = 'application/cdmi-container'
       header['Content-Type'] = 'application/cdmi-container'
       #body optional
       body = {}
       body['metadata'] = ''
       body['domainURI'] = ''
       body['exports'] = ''
       body['deserialize'] =''
       body['copy']=''
       body['move']=''
       body['reference'] = ''
       body['deserializevalue'] = ''
       container_uri= '/Gerd2'
       url = @endpointendpoint+ container_uri
       response = RestClient.post url, header, body 
       #add exception here
       #puts response
     end 
     
    def get_container(path)
      header = {}
      header['X-CDMI-Specification-Version'] = '1.0'
      header['Accept'] = 'application/cdmi-container'
	  url = @endpoint + container_uri
      response = RestClient.get url, header
      #add exception here
    end
    
    def update_container(path)
      header={}
      header['X-CDMI-Specification-Version'] = '1.0'
      header['Accept'] = 'application/cdmi-container'
      header['Content-Type'] = 'application/cdmi-container'
      #body optional
      body = {}
      body['metadata'] = ''
      body['domainURI'] = ''
      body['snapshot'] = ''
      body['exports'] =''
      url = @endpoint + container_uri
      response = RestClient.put url, header
            #add exception here
    end
    
    def delete_cotainer(path)
      header = {}
      header['X-CDMI-Specification-Version'] = '1.0'
      url = @endpoint + container_uri
      response = RestClient.delete url, header
    end
	 
    def create_dataobject_in_container(path)
      header = {}
      header['X-CDMI-Specification-Version'] = '1.0'
      header['Accept'] = 'application/cdmi_object'
      header['Content-Type'] = 'application/cdmi_object'
      #optional
      body = {}
      body['mimetype'] = ''
      body['metadata'] = ''
      body['domainURI'] = ''
      body['deserialize'] =''
      body['serialize'] = ''
      body['copy']=''
      body['move']=''
      body['reference'] = ''
      body['deserializevalue'] = ''
      body['value']=''
      url = @endpoint + container_uri
      response = RestClient.post url, header, body
      #add exception
    end
    
   def create_dataobject(path)
     header = {}
     header['X-CDMI-Specification-Version'] = '1.0'
     header['Accept'] = 'application/cdmi_object'
     header['Content-Type'] = 'application/cdmi_object'
     #optional 
     #header['X-CDMI-Partial'] = ''
     #optional body
     body = {}
     body['mimetype'] = ''
     body['metadata'] = ''
     body['domainURI'] = ''
     body['deserialize'] =''
     body['serialize'] = ''
     body['copy']=''
     body['move']=''
     body['reference'] = ''
     body['deserializevalue'] = ''
     body['value']=''
     url = @endpoint + container_uri + dataobject_uri
     response = RestClient.put url, header, body
     #add exception
   end
   
   def read_dataobject(path)
     header = {}
     header['X-CDMI-Specification-Version'] = '1.0'
     header['Accept'] = 'application/cdmi_object'
     url = @endpoint + container_uri + dataobject_uri
     response = RestClient.get url, header, body
     #add exception
   end
   
   def update_dataobject(path)
     header = {}
     header['X-CDMI-Specification-Version'] = '1.0'
     header['Accept'] = 'application/cdmi_object'
     header['Content-Type'] = 'application/cdmi_object'
     #optional 
     #header['X-CDMI-Partial'] = ''
     #optional body
     body = {}
     body['mimetype'] = ''
     body['metadata'] = ''
     body['domainURI'] = ''
     body['value'] = ''
     url = @endpoint + container_uri + dataobject_uri
     response = RestClient.put url, header, body
     #add exception
   end
   
  def delete_dataobject(path)
    header = {}
    header['X-CDMI-Specification-Version'] = '1.0'
    url = @endpoint + container_uri + dataobject_uri
    response = RestClient.delete url, header
    #add exception
  end
   
#new ends here
    
   def dump()
  	LOG.echo( "OCCI2CDMIBroker", "@endpoint='%s'" %@endpoint  )
  	LOG.echo( "OCCI2CDMIBroker", "@server='%s'"   %@server    )
  	LOG.echo( "OCCI2CDMIBroker", "@container='%s'"%@container )
   end	

end  # END-OF-CLASS

begin
    broker = OCCI2CDMIBroker.new()
    broker.useCase()
	broker.dump()
end 